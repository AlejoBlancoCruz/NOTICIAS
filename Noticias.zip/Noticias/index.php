<?php
    header("Location:./vista/principal.php");
?>