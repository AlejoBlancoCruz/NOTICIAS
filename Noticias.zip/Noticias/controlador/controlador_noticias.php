<?php
    $xml_file_content = file_get_contents('https://newsapi.org/v2/everything?q=espa%C3%B1a&apiKey=a25a8d6b2a024a16bb0e063996a28526&language=es');
    $datos = json_decode($xml_file_content, true);
    echo json_encode($datos);
?>