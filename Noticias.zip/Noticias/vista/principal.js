const selectNoticias = document.getElementById("provincias")

window.onload = function() {
    muestraNoticias();
}

function muestraNoticias() {
    let urlNoticias = "../controlador/controlador_noticias.php"
    fetch(urlNoticias)
    .then(res => res.json())
    .then(response => {
        console.log(response)
        let fragmento = document.createDocumentFragment()
        for (let i in response.provinciero.prov){
            let opcion = document.createElement("option")
            opcion.value = response.provinciero.prov[i].cpine
            opcion.text = response.provinciero.prov[i].np
            fragmento.appendChild(opcion)
        }
        selectProvincia.appendChild(fragmento)
        muestraMunicipios(selectProvincia.options[selectProvincia.selectedIndex].text)
    })
}


document.getElementById("provincias").addEventListener("change", () => {
    muestraMunicipios(selectProvincia.options[selectProvincia.selectedIndex].text)
})

