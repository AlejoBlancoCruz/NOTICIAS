<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./style.css">

    <title>Climatólogo amateur</title>
</head>
<body>
    <div class="selector">
        <div class="datosSelector">
            <label for="provincias">Seleccione una provincia: </label>
            <select name="provincias" id="provincias"></select>
        </div>
        <div class="datosSelector">
            <label for="municipios">Seleccione un municipio: </label>
            <select name="municipios" id="municipios"></select>
        </div>
    </div>
    <div id="resultado"></div>
    <div id="termometro"></div>

    <script src="./principal.js"></script>
</body>
</html>
